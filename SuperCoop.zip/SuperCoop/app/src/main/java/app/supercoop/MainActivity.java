package app.supercoop;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private Sensor sensors = new Sensor();
    private boolean fanOn = false;

    private FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference tempRef = database.getReference("sensors/temp");
    private DatabaseReference humidRef = database.getReference("sensors/humid");
    private DatabaseReference ammoniaRef = database.getReference("sensors/ammonia");
    private DatabaseReference fanRef = database.getReference("sensors/fan");
    private FirebaseAuth auth;
    private FirebaseUser user;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        tempRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                // This method is called once with the initial value and again
                // whenever data at this location is updated.
                sensors.setTemp((String)dataSnapshot.getValue());
                ((TextView)findViewById(R.id.var_temp)).setText(sensors.getTemp());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        humidRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                sensors.setHumid((String)dataSnapshot.getValue());
                ((TextView)findViewById(R.id.var_humid)).setText(sensors.getHumid());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });

        ammoniaRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                sensors.setAmmonia((String)dataSnapshot.getValue());
                ((TextView)findViewById(R.id.var_ammonia)).setText(sensors.getAmmonia());
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        });


    }



    public void fanClick(View v) {
        fanOn = !fanOn;

        if(fanOn)
            ((TextView)findViewById(R.id.button)).setText("Fan is On");
        else
            ((TextView)findViewById(R.id.button)).setText("Fan is Off");

        writeFanFirebase();

    }

    private void writeFanFirebase()
    {
        //user.
        fanRef.setValue(fanOn);
    }

}
